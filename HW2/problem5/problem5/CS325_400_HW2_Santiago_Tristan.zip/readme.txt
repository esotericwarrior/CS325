Tristan Santiago
CS325_400
October 7, 2018

Instructions for compiling program on FLIP.

To compile problem5.cpp, type the following on the command line:
g++ -std=c++11 problem5.cpp -o problem5