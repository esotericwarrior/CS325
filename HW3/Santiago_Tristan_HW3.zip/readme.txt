Tristan Santiago
CS325_400
October 14, 2018

Instructions for compiling program on FLIP.

To compile shopping.cpp, type the following on the command line:
g++ -std=c++11 shopping.cpp -o shopping