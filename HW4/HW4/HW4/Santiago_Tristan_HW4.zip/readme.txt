Tristan Santiago
CS325_400
October 21, 2018

Instructions for compiling each program on FLIP.

To compile HW4.cpp, type the following on the command line:
g++ -std=c++11 HW4.cpp -o HW4